#ifndef _DEVICELIBRARY_H_
#define _DEVICELIBRARY_H_

extern int processMoveDevice(int posIni, int posFin, int nextMove);
extern int processBoardDevice(int sizeBoard);

#endif
